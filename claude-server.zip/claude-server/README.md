# claude-server

Локальный HTTP-сервер, оборачивающий Claude Code CLI (`claude -p`) в API,
совместимый с OpenAI Chat Completions. Использует твою существующую
авторизацию по подписке Max (`claude login`) — никакого `ANTHROPIC_API_KEY`
не нужно. Каждый запрос запускает `claude` как дочерний процесс.

## Требования

- Node.js >= 18
- Установленный и авторизованный Claude Code CLI:
  ```bash
  npm install -g @anthropic-ai/claude-code
  claude login
  ```

## Запуск

```bash
cd claude-server
node server.js
```

По умолчанию слушает `http://127.0.0.1:8137` (только localhost).

### Переменные окружения

| Переменная               | По умолчанию | Описание                                              |
|---------------------------|--------------|--------------------------------------------------------|
| `CLAUDE_SERVER_PORT`      | `8137`       | Порт                                                    |
| `CLAUDE_SERVER_HOST`      | `127.0.0.1`  | Адрес для bind                                          |
| `CLAUDE_SERVER_TOKEN`     | не задан     | Если задан — требуется `Authorization: Bearer <token>` |
| `CLAUDE_SERVER_TIMEOUT_MS`| `900000`     | Таймаут одного запроса к `claude` (мс)                  |
| `CLAUDE_BIN`               | `claude`     | Путь/имя бинарника CLI                                  |

## Эндпоинты

| Метод | Путь                    | Описание                                        |
|-------|--------------------------|--------------------------------------------------|
| GET   | `/health`                | Проверка живости                                  |
| GET   | `/v1/models`              | Список моделей (OpenAI-формат)                    |
| POST  | `/v1/chat/completions`    | Основной, OpenAI-совместимый (стрим и без стрима) |
| POST  | `/ask`                    | Упрощённый нативный эндпоинт (см. ниже)           |

---

## CURL примеры

### Health check

```bash
curl http://127.0.0.1:8137/health
```

### Список моделей

```bash
curl http://127.0.0.1:8137/v1/models
```

### Chat Completions — обычный запрос (без стрима)

```bash
curl -X POST http://127.0.0.1:8137/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "opus",
    "messages": [
      {"role": "system", "content": "Отвечай коротко."},
      {"role": "user", "content": "Столица Франции?"}
    ]
  }'
```

Ответ (формат идентичен OpenAI):

```json
{
  "id": "chatcmpl-...",
  "object": "chat.completion",
  "created": 1785578378,
  "model": "opus",
  "choices": [
    {
      "index": 0,
      "message": { "role": "assistant", "content": "Париж" },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 21736,
    "completion_tokens": 72,
    "total_tokens": 21808
  }
}
```

### Chat Completions — потоковый ответ (SSE)

```bash
curl -N -X POST http://127.0.0.1:8137/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "opus",
    "stream": true,
    "messages": [
      {"role": "user", "content": "Посчитай от 1 до 5, по одному числу в строке."}
    ]
  }'
```

Ответ (`-N` отключает буферизацию curl, чтобы видеть чанки в реальном времени):

```
data: {"id":"chatcmpl-...","object":"chat.completion.chunk","created":1785578385,"model":"opus","choices":[{"index":0,"delta":{"role":"assistant","content":""},"finish_reason":null}]}

data: {"id":"chatcmpl-...","object":"chat.completion.chunk","created":1785578385,"model":"opus","choices":[{"index":0,"delta":{"content":"1\n2\n3\n4\n5"},"finish_reason":null}]}

data: {"id":"chatcmpl-...","object":"chat.completion.chunk","created":1785578385,"model":"opus","choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}

data: [DONE]
```

### Многоходовой диалог (история сообщений)

```bash
curl -X POST http://127.0.0.1:8137/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "opus",
    "messages": [
      {"role": "user", "content": "Меня зовут Джавхарбек."},
      {"role": "assistant", "content": "Приятно познакомиться, Джавхарбек!"},
      {"role": "user", "content": "Как меня зовут? Ответь только именем."}
    ]
  }'
```

### С Bearer-токеном (если задан `CLAUDE_SERVER_TOKEN`)

```bash
curl -X POST http://127.0.0.1:8137/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"model": "opus", "messages": [{"role": "user", "content": "Привет"}]}'
```

### Легаси-эндпоинт `/ask` (простой, без OpenAI-обёртки)

```bash
curl -X POST http://127.0.0.1:8137/ask \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Скажи привет"}'
```

Разрешить Claude пользоваться инструментами (Bash, файлы и т.д.) без
интерактивного подтверждения:

```bash
curl -X POST http://127.0.0.1:8137/ask \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Создай файл hello.txt с текстом Hello World",
    "cwd": "C:/path/to/project",
    "allowTools": true
  }'
```

---

## Использование с OpenAI SDK

### Python

```python
from openai import OpenAI

client = OpenAI(base_url="http://127.0.0.1:8137/v1", api_key="not-needed")

resp = client.chat.completions.create(
    model="opus",
    messages=[{"role": "user", "content": "Привет!"}],
)
print(resp.choices[0].message.content)

# Стриминг
stream = client.chat.completions.create(
    model="opus",
    messages=[{"role": "user", "content": "Посчитай от 1 до 5"}],
    stream=True,
)
for chunk in stream:
    delta = chunk.choices[0].delta.content
    if delta:
        print(delta, end="", flush=True)
```

### Node.js

```javascript
import OpenAI from "openai";

const client = new OpenAI({
  baseURL: "http://127.0.0.1:8137/v1",
  apiKey: "not-needed",
});

const resp = await client.chat.completions.create({
  model: "opus",
  messages: [{ role: "user", content: "Привет!" }],
});
console.log(resp.choices[0].message.content);
```

---

## Дополнительные поля в `/v1/chat/completions` (нестандартные, опциональные)

| Поле              | Тип     | Описание                                                          |
|-------------------|---------|---------------------------------------------------------------------|
| `cwd`             | string  | Рабочая директория для Claude                                       |
| `session_id`      | string  | Продолжить существующую сессию Claude Code (`--resume`)             |
| `allow_tools`     | boolean | Разрешить Bash/файлы и т.д. без подтверждения (`--dangerously-skip-permissions`) |
| `permission_mode` | string  | `acceptEdits` \| `auto` \| `bypassPermissions` \| `manual`          |
| `effort`          | string  | `low` \| `medium` \| `high` \| `xhigh` \| `max` — прокидывается как `--effort`. Ниже effort = меньше "думания" перед ответом, заметно быстрее на сложных промптах (в тестах генерация IELTS-теста: ~6 мин на дефолтном effort против ~1 мин на `low`). |

### Мышление модели и `reasoning_tokens` в стриме

На сложных промптах (например, "сгенерируй большой структурированный JSON")
Sonnet/Opus обычно тратит от десятков секунд до нескольких **минут** на
extended thinking, прежде чем появится первый видимый текст. Claude Code CLI
не отдаёт сам текст размышлений через `--include-partial-messages` (он
редактируется), только грубую оценку размера очередного блока —
`estimated_tokens`. Чтобы стриминг не выглядел как зависание, каждый такой
чанк сервер пробрасывает клиенту как нестандартное поле в SSE-чанке:

```
data: {"choices":[{"delta":{"reasoning_tokens": 684}, "finish_reason": null}]}
```

`reasoning_tokens` — это накопленная оценка количества токенов размышления
на текущий момент (растёт, пока не появится обычный `delta.content`).
Клиенты, не знающие про это поле, могут его просто игнорировать — оно
всегда в отдельном чанке, не смешивается с `content`.

## Ограничения

- `temperature`, `top_p`, `max_tokens`, `n`, `stop` принимаются в теле
  запроса ради совместимости формата, но CLI `claude -p` их не поддерживает
  — реально не влияют на генерацию.
- `function_call` / `tool_calls` (вызовы функций в стиле OpenAI) не
  эмулируются.
- Каждый запрос — новый процесс `claude`. Для настоящего сохранения сессии
  между запросами используй `session_id` + `--resume` (см. таблицу выше).
- Если клиент отключается до завершения ответа (fetch abort/timeout,
  закрытая вкладка), сервер убивает дочерний процесс `claude` вместо того,
  чтобы оставлять его работать вхолостую до истечения таймаута.

## Безопасность

- По умолчанию сервер слушает только `127.0.0.1` — не открывай его наружу
  без дополнительной аутентификации (`CLAUDE_SERVER_TOKEN`) и понимания
  рисков: эндпоинт исполняет произвольные промпты через Claude Code.
- Инструменты (Bash, редактирование файлов) по умолчанию выключены — их
  нужно явно включать через `allow_tools` / `allowTools`.

## Использование из браузера (CORS)

Сервер отдаёт заголовки `Access-Control-Allow-*` на каждый ответ и отвечает
на preflight `OPTIONS`, поэтому его можно вызывать напрямую через `fetch`
со страницы, открытой из `file://` или с другого `http://` origin — не
только из Node/Python-скриптов.

`ielts_reading.html` и `ielts_writing.html` в этом репозитории используют
это: в их Settings → AI Integration есть переключатель **OpenRouter /
Claude Server (local)** — при выборе Claude Server они ходят прямо в
`http://127.0.0.1:8137/v1/chat/completions` вместо OpenRouter, без
API-ключа, используя твою логику Claude Code (`claude login`). Так как CLI
не поддерживает произвольные tool-schema от вызывающей стороны, в этом
режиме структурированный JSON (тест/задание/оценка) запрашивается прямым
текстовым промптом, а не через `tools`/`tool_choice` — просто запусти
`node claude-server/server.js` перед тем как включать этот режим в
настройках.
